package vk.edu.page;

public class ProfilePage {

}

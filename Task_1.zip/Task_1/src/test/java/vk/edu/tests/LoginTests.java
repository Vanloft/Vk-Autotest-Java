package vk.edu.tests;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import vk.edu.page.LoginPage;

import static com.codeborne.selenide.Condition.attribute;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.*;

public class LoginTests extends BaseTest{
    private final static String BASE_URL = "https://ok.ru/";

    @Test
    public void sucLogin(){
        LoginPage loginpage = new LoginPage(BASE_URL);
        loginpage.clickOnFieldEmail();
        sleep(5000);
        loginpage.clickOnFieldPassword();
        loginpage.enter();
        $(By.xpath(".//*[@id='hook_Block_Navigation']//*[@data-l='t,userPage']//*[text()='technopol41 technopol41']")).shouldBe(visible);
    }
}
